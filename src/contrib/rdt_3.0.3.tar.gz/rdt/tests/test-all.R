library(testthat)

testthat::test_check("rdt")
